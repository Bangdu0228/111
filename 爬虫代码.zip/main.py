from DrissionPage import ChromiumPage
import time


print('软件开始执行')
print('请输入执行的范围 1-500 501-1000 以此类推 以每500为一个范围')
begin_num = int(input('1-500输入1 501-1000 输入501 请输入: '))

page = ChromiumPage()
page.get('https://www.cnki.net/')
input('登录账号成功后按下回车继续执行')
page.get('https://kns.cnki.net/kns8s/AdvSearch?crossids=YSTT4HG0%2CLSTPFY1C%2CJUP3MUPD%2CMPMFIG1A%2CWQ0UVIAA%2CBLZOG7CK%2CEMRPGLPA%2CPWFIRAGL%2CNLBO1Z6R%2CNN3FJMUV')
input('手动输入搜索关键词以及年份点击搜索后按下回车继续执行')

page_50 = page.ele('#perPageDiv').click()
time.sleep(3)
page.ele('xpath://*[@id="perPageDiv"]/ul/li[3]').click()
time.sleep(5)

# page_num = page.ele('.countPageMark').text
# now_page_index = str(page_num).find('/')
# now_page = page_num[:now_page_index]
# print(f'总计页码 {page_num}')
# print(f'当前页码数 {now_page}')
page.ele('xpath://*[@id="briefBox"]/div[1]/div/div[2]/div[1]/a').click()
page.ele('text:相关度').click()
page.ele('xpath://*[@id="perPageDiv"]').click()

cop_num = (begin_num - 1) / 500 
if cop_num == 0 :
    begin_page = 0
else:
    begin_page = cop_num * 10

print(f'开始执行的页码 {begin_page}')
time.sleep(5)


if begin_page != 0:
    for x in range(begin_page):
        page.ele('xpath://*[@id="Page_next_top"]').click()
        time.sleep(2)
        page.ele('xpath://*[@id="gridTable"]/div/div/table/tbody/tr[1]/td[2]/a')


for x in range(10):
    page_num = page.ele('.countPageMark').text
    now_page_index = str(page_num).find('/')
    now_page = page_num[:now_page_index]
    print(f'总计页码 {page_num}')
    print(f'当前页码数 {now_page}')
    #执行全选
    page.ele('xpath://*[@id="selectCheckAll1"]').click()
    time.sleep(2)
    #下一页
    page.ele('xpath://*[@id="Page_next_top"]').click()
    time.sleep(2)
    page.ele('xpath://*[@id="gridTable"]/div/div/table/tbody/tr[1]/td[2]/a')


page.ele('xpath://*[@id="batchOpsBox"]/li[2]/a').click()
time.sleep(2)
page.ele('xpath://*[@id="batchOpsBox"]/li[2]/ul/li[1]/a').click()
time.sleep(2)
page.ele('xpath://*[@id="batchOpsBox"]/li[2]/ul/li[1]/ul/li[8]/a').click()
time.sleep(2)

tab = page.get_tab(0)
tab.set.download_path(r'F:\P301')
for x in range(3):
    tab.ele('xpath://*[@id="litotxt"]').click()
    tab.wait.download_begin()
    tab.wait.downloads_done()
    time.sleep(3)

input('执行完成')
