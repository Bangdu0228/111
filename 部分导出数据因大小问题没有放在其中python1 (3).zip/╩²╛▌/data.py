import os

# 定义文件夹路径和输出文件名
folder_path = 'data'
output_file = 'result.txt'

# 创建一个空的文本文件，用于存储所有数据
with open(output_file, 'w', encoding='utf-8') as outfile:
    # 获取文件夹下所有txt文件的文件名
    files = [f for f in os.listdir(folder_path) if f.endswith('.txt')]
    # 遍历所有txt文件，并将它们写入输出文件中
    for file in files:
        file_path = os.path.join(folder_path, file)
        with open(file_path, 'r', encoding='utf-8') as infile:
            outfile.write(infile.read())


